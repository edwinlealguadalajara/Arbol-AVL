#ifndef AVLTREE_H
#define AVLTREE_H

#include <iostream>
#include <queue>
#include <stdexcept>
#include <algorithm>
#include "AVLNode.h"

/**
 * @file AVLTree.h
 * @brief Clase principal que implementa un Arbol Binario de Busqueda Auto-balanceado (AVL).
 * @author Edwin Leal
 * @version 1.0
 */

template <typename T>
class AVLTree {
 private:
  AVLNode<T>* root;
  int nodeCount;

  // Auxiliares de altura y balance
  int nodeHeight(AVLNode<T>* node) const;
  int getBalanceFactor(AVLNode<T>* node) const;
  void updateHeight(AVLNode<T>* node);

  // Las 4 rotaciones obligatorias
  AVLNode<T>* rotateRight(AVLNode<T>* y);
  AVLNode<T>* rotateLeft(AVLNode<T>* x);
  AVLNode<T>* rotateLeftRight(AVLNode<T>* node);
  AVLNode<T>* rotateRightLeft(AVLNode<T>* node);

  // Metodos recursivos internos
  AVLNode<T>* insertHelper(AVLNode<T>* node, const T& value, bool& inserted);
  AVLNode<T>* removeHelper(AVLNode<T>* node, const T& value, bool& removed);
  AVLNode<T>* minValueNode(AVLNode<T>* node) const;
  AVLNode<T>* maxValueNode(AVLNode<T>* node) const;
  bool searchHelper(AVLNode<T>* node, const T& value) const;
  void clearHelper(AVLNode<T>* node);

  // Recorridos auxiliares
  void inOrderHelper(AVLNode<T>* node) const;
  void preOrderHelper(AVLNode<T>* node) const;
  void postOrderHelper(AVLNode<T>* node) const;

 public:
  /**
   * @brief Constructor del arbol AVL vacio.
   */
  AVLTree();

  /**
   * @brief Destructor que libera toda la memoria dinamica usada.
   */
  ~AVLTree();

  // Evitar copias superficiales accidentales (Regla de 3/5)
  AVLTree(const AVLTree& other) = delete;
  AVLTree& operator=(const AVLTree& other) = delete;

  /**
   * @brief Inserta un nuevo elemento en el arbol y lo rebalancea si hace falta.
   * @param value Valor a insertar.
   */
  void insert(const T& value);

  /**
   * @brief Elimina un elemento del arbol manteniendo la propiedad AVL.
   * @param value Valor a borrar.
   */
  void remove(const T& value);

  /**
   * @brief Busca si un elemento existe dentro del arbol.
   * @param value Elemento a buscar.
   * @return true si lo encuentra, false si no esta.
   */
  bool search(const T& value) const;

  /**
   * @brief Obtiene el valor mas pequeño del arbol.
   * @return Referencia constante al valor minimo.
   */
  const T& findMin() const;

  /**
   * @brief Obtiene el valor mas grande del arbol.
   * @return Referencia constante al valor maximo.
   */
  const T& findMax() const;

  /**
   * @brief Devuelve la altura total del arbol.
   * @return Altura (0 si esta vacio).
   */
  int getHeight() const;

  /**
   * @brief Devuelve la cantidad total de nodos almacenados.
   * @return Numero de nodos.
   */
  int getSize() const;

  /**
   * @brief Elimina todos los nodos y libera la memoria.
   */
  void clear();

  // Recorridos obligatorios
  void inOrder() const;
  void preOrder() const;
  void postOrder() const;
  void levelOrder() const;
};

#include "../src/AVLTree.cpp"

#endif  // AVLTREE_H
