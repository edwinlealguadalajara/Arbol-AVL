#ifndef AVLNODE_H
#define AVLNODE_H

/**
 * @file AVLNode.h
 * @brief Definicion de la clase plantilla para los nodos del arbol AVL.
 * @author Edwin Leal
 * @date Noviembre 2026
 */

template <typename T>
class AVLNode {
 public:
  T data;
  AVLNode<T>* left;
  AVLNode<T>* right;
  int height;

  /**
   * @brief Constructor por defecto / parametrizado del nodo.
   * @param value El dato a guardar en el nodo.
   */
  explicit AVLNode(const T& value);

  /**
   * @brief Destructor del nodo.
   */
  ~AVLNode() = default;
};

#include "../src/AVLNode.cpp"

#endif  // AVLNODE_H
