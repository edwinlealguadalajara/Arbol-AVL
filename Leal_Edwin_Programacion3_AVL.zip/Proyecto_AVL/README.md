# Proyecto Final - Arbol AVL en C++

Implementacion completa de un Arbol Binario de Busqueda Auto-balanceado (AVL) usando plantillas (`templates`) en C++17, separado en archivos de cabecera e implementacion.

**Autor:** Edwin Leal  
**Materia:** Programacion 3 (Grupo 9-11 LM)  
**Universidad:** Centro Universitario de Guadalajara (CUGDL) - UDG  

---

## Estructura del Proyecto

```text
Proyecto_AVL/
├── include/
│   ├── AVLTree.h
│   └── AVLNode.h
├── src/
│   ├── AVLTree.cpp
│   ├── AVLNode.cpp
│   └── main.cpp
├── Makefile
└── README.md
```

*Nota tecnica sobre templates:* Como C++ necesita ver la definicion completa de las plantillas en tiempo de compilacion para instanciar los tipos, los `.h` incluyen al final sus respectivos `.cpp` usando guardas de inclusion (`#ifndef`) para evitar errores de definicion multiple y mantener la estructura pedida.

---

## Requisitos y Compilacion

El proyecto esta configurado para compilar con `g++` bajo el estandar **C++17** y todas las banderas estrictas de advertencias activadas (`-Wall -Wextra -Wpedantic -Werror -g`).

### Comandos disponibles con Make:

1. **Compilar el proyecto:**
   ```bash
   make
   ```

2. **Compilar y ejecutar las pruebas:**
   ```bash
   make run
   ```

3. **Verificar fuga de memoria con Valgrind:**
   ```bash
   make valgrind
   ```

4. **Limpiar ejecutables:**
   ```bash
   make clean
   ```

Si no tienes `make` instalado, puedes compilar directo desde terminal con:
```bash
g++ -std=c++17 -Wall -Wextra -Wpedantic -Werror -g -Iinclude src/main.cpp -o avl_test
./avl_test
```

---

## Operaciones Implementadas y Complejidad

| Metodo | Complejidad | Descripcion |
| :--- | :---: | :--- |
| `insert(T)` | $O(\log n)$ | Inserta el dato y ejecuta rotaciones si el factor de balance sale de $[-1, 1]$. |
| `remove(T)` | $O(\log n)$ | Elimina un nodo (0, 1 o 2 hijos) y rebalancea hacia arriba hasta la raiz. |
| `search(T)` | $O(\log n)$ | Busqueda binaria recursiva en el arbol. |
| `findMin()` / `findMax()` | $O(\log n)$ | Retorna el menor o mayor elemento (lanza `runtime_error` si esta vacio). |
| `getHeight()` | $O(1)$ | Devuelve la altura almacenada en el nodo raiz. |
| `getSize()` | $O(1)$ | Devuelve el contador interno de nodos. |
| `clear()` | $O(n)$ | Recorrido post-order para hacer `delete` de cada nodo sin dejar leaks. |

### Recorridos disponibles
- `inOrder()`: Izquierda -> Raiz -> Derecha (imprime los datos ordenados).
- `preOrder()`: Raiz -> Izquierda -> Derecha.
- `postOrder()`: Izquierda -> Derecha -> Raiz.
- `levelOrder()`: Recorrido por niveles usando `std::queue`.

---

## Casos de Prueba Incluidos (`main.cpp`)

El archivo `main.cpp` corre una bateria de pruebas automaticas con `assert`:
1. **Rotaciones fundamentales:** Inserciones especificas para forzar y verificar los 4 casos (`LL`, `RR`, `LR`, `RL`).
2. **Operaciones basicas:** Insercion de elementos desordenados, rechazo de duplicados, `findMin`, `findMax`, `search` y los 4 recorridos.
3. **Eliminaciones y casos borde:** Manejo de excepciones en arbol vacio, insercion secuencial del 1 al 15 (verificando altura logaritmica = 4), borrado de hojas, nodos con 1 hijo, nodos con 2 hijos y limpieza total con `clear()`.
4. **Genericos:** Prueba del arbol usando `std::string` en lugar de enteros.
