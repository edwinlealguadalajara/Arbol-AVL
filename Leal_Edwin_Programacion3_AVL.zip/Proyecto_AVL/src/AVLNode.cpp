#ifndef AVLNODE_CPP
#define AVLNODE_CPP

#include "../include/AVLNode.h"

/**
 * @file AVLNode.cpp
 * @brief Implementacion de los metodos del nodo AVL.
 */

template <typename T>
AVLNode<T>::AVLNode(const T& value)
    : data(value), left(nullptr), right(nullptr), height(1) {}

#endif  // AVLNODE_CPP
