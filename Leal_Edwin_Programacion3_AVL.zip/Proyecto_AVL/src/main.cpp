#include <iostream>
#include <cassert>
#include <string>
#include "../include/AVLTree.h"

/**
 * @file main.cpp
 * @brief Suite de pruebas exhaustivas para validar el Arbol AVL.
 * @author Edwin Leal
 */

void testRotations() {
  std::cout << "=== 1. PROBANDO LAS 4 ROTACIONES FUNDAMENTALES ===" << std::endl;

  // Caso LL (Rotacion derecha)
  AVLTree<int> treeLL;
  treeLL.insert(30);
  treeLL.insert(20);
  treeLL.insert(10);  // Aqui se dispara rotateRight
  assert(treeLL.getHeight() == 2);
  assert(treeLL.getSize() == 3);
  std::cout << "[OK] Rotacion LL (30, 20, 10) -> Altura: " << treeLL.getHeight()
            << " | LevelOrder: ";
  treeLL.levelOrder();

  // Caso RR (Rotacion izquierda)
  AVLTree<int> treeRR;
  treeRR.insert(10);
  treeRR.insert(20);
  treeRR.insert(30);  // Aqui se dispara rotateLeft
  assert(treeRR.getHeight() == 2);
  std::cout << "[OK] Rotacion RR (10, 20, 30) -> Altura: " << treeRR.getHeight()
            << " | LevelOrder: ";
  treeRR.levelOrder();

  // Caso LR (Rotacion izquierda-derecha)
  AVLTree<int> treeLR;
  treeLR.insert(30);
  treeLR.insert(10);
  treeLR.insert(20);  // Aqui se dispara rotateLeftRight
  assert(treeLR.getHeight() == 2);
  std::cout << "[OK] Rotacion LR (30, 10, 20) -> Altura: " << treeLR.getHeight()
            << " | LevelOrder: ";
  treeLR.levelOrder();

  // Caso RL (Rotacion derecha-izquierda)
  AVLTree<int> treeRL;
  treeRL.insert(10);
  treeRL.insert(30);
  treeRL.insert(20);  // Aqui se dispara rotateRightLeft
  assert(treeRL.getHeight() == 2);
  std::cout << "[OK] Rotacion RL (10, 30, 20) -> Altura: " << treeRL.getHeight()
            << " | LevelOrder: ";
  treeRL.levelOrder();
  std::cout << std::endl;
}

void testOperationsAndTraversals() {
  std::cout << "=== 2. PROBANDO INSERCIONES, BUSQUEDA, MIN/MAX Y RECORRIDOS ===" << std::endl;
  AVLTree<int> avl;
  int values[] = {50, 25, 75, 10, 30, 60, 80, 5, 15, 27, 55};

  for (int v : values) {
    avl.insert(v);
  }

  // Probar duplicados (no deben aumentar el size)
  int sizeBefore = avl.getSize();
  avl.insert(25);
  assert(avl.getSize() == sizeBefore);
  std::cout << "[OK] Ignora duplicados correctamente (Size = " << avl.getSize() << ")" << std::endl;

  // Minimo y Maximo
  assert(avl.findMin() == 5);
  assert(avl.findMax() == 80);
  std::cout << "[OK] Minimo: " << avl.findMin() << " | Maximo: " << avl.findMax() << std::endl;

  // Busqueda
  assert(avl.search(27) == true);
  assert(avl.search(999) == false);
  std::cout << "[OK] Busqueda funcional (27 encontrado, 999 no encontrado)" << std::endl;

  // Recorridos
  std::cout << "InOrder (ordenado): ";
  avl.inOrder();
  std::cout << "PreOrder:           ";
  avl.preOrder();
  std::cout << "PostOrder:          ";
  avl.postOrder();
  std::cout << "LevelOrder:         ";
  avl.levelOrder();
  std::cout << std::endl;
}

void testDeletionsAndEdgeCases() {
  std::cout << "=== 3. PROBANDO ELIMINACIONES Y CASOS BORDE ===" << std::endl;
  AVLTree<int> avl;

  // Caso borde: arbol vacio
  assert(avl.getHeight() == 0);
  assert(avl.getSize() == 0);
  assert(avl.search(10) == false);
  bool exceptionCaught = false;
  try {
    avl.findMin();
  } catch (const std::runtime_error&) {
    exceptionCaught = true;
  }
  assert(exceptionCaught);
  std::cout << "[OK] Excepcion controlada al pedir findMin() en arbol vacio" << std::endl;

  // Insertamos secuencia del 1 al 15 (peor caso para un ABB normal, altura seria 15)
  for (int i = 1; i <= 15; ++i) {
    avl.insert(i);
  }
  // Con 15 nodos en AVL perfecto, la altura debe ser exactamente 4
  assert(avl.getHeight() == 4);
  assert(avl.getSize() == 15);
  std::cout << "[OK] 15 elementos secuenciales insertados -> Altura AVL: " << avl.getHeight() << std::endl;

  // Borrar hoja
  avl.remove(1);
  assert(!avl.search(1));
  assert(avl.getSize() == 14);

  // Borrar nodo con 1 hijo
  avl.remove(2);
  assert(!avl.search(2));

  // Borrar nodo con 2 hijos (la raiz o subraiz) y forzar rebalanceo
  avl.remove(8);
  avl.remove(4);
  avl.remove(12);
  assert(!avl.search(8));
  assert(avl.getSize() == 10);
  std::cout << "[OK] Eliminaciones (0, 1 y 2 hijos) completadas. Nueva altura: " << avl.getHeight() << std::endl;
  std::cout << "InOrder tras borrar: ";
  avl.inOrder();

  // Borrar algo que no existe
  avl.remove(404);
  assert(avl.getSize() == 10);

  // Vaciar arbol
  avl.clear();
  assert(avl.getSize() == 0);
  assert(avl.getHeight() == 0);
  std::cout << "[OK] clear() vacio el arbol correctamente." << std::endl;
  std::cout << std::endl;
}

void testGenericTemplate() {
  std::cout << "=== 4. PROBANDO PLANTILLA GENERICA CON STRINGS ===" << std::endl;
  AVLTree<std::string> words;
  words.insert("Guadalajara");
  words.insert("CUGDL");
  words.insert("Algoritmos");
  words.insert("Estructura");
  words.insert("Zacatecas");

  assert(words.findMin() == "Algoritmos");
  assert(words.findMax() == "Zacatecas");
  std::cout << "InOrder strings: ";
  words.inOrder();
  std::cout << std::endl;
}

int main() {
  testRotations();
  testOperationsAndTraversals();
  testDeletionsAndEdgeCases();
  testGenericTemplate();

  std::cout << "TODAS LAS PRUEBAS PASARON EXITOSAMENTE!" << std::endl;
  return 0;
}
