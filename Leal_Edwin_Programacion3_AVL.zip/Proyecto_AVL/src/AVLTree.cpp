#ifndef AVLTREE_CPP
#define AVLTREE_CPP

#include "../include/AVLTree.h"

/**
 * @file AVLTree.cpp
 * @brief Implementacion de las operaciones, rotaciones y recorridos del arbol AVL.
 */

template <typename T>
AVLTree<T>::AVLTree() : root(nullptr), nodeCount(0) {}

template <typename T>
AVLTree<T>::~AVLTree() {
  clear();
}

template <typename T>
int AVLTree<T>::nodeHeight(AVLNode<T>* node) const {
  return (node == nullptr) ? 0 : node->height;
}

template <typename T>
int AVLTree<T>::getBalanceFactor(AVLNode<T>* node) const {
  if (node == nullptr) {
    return 0;
  }
  return nodeHeight(node->left) - nodeHeight(node->right);
}

template <typename T>
void AVLTree<T>::updateHeight(AVLNode<T>* node) {
  if (node != nullptr) {
    node->height = 1 + std::max(nodeHeight(node->left), nodeHeight(node->right));
  }
}

// Rotacion simple a la derecha (Caso LL)
template <typename T>
AVLNode<T>* AVLTree<T>::rotateRight(AVLNode<T>* y) {
  AVLNode<T>* x = y->left;
  AVLNode<T>* T2 = x->right;

  // Hacemos el giro
  x->right = y;
  y->left = T2;

  // Actualizamos alturas (primero y porque quedo abajo)
  updateHeight(y);
  updateHeight(x);

  return x;
}

// Rotacion simple a la izquierda (Caso RR)
template <typename T>
AVLNode<T>* AVLTree<T>::rotateLeft(AVLNode<T>* x) {
  AVLNode<T>* y = x->right;
  AVLNode<T>* T2 = y->left;

  // Hacemos el giro
  y->left = x;
  x->right = T2;

  // Actualizamos alturas (primero x porque quedo abajo)
  updateHeight(x);
  updateHeight(y);

  return y;
}

// Rotacion doble Izquierda-Derecha (Caso LR)
template <typename T>
AVLNode<T>* AVLTree<T>::rotateLeftRight(AVLNode<T>* node) {
  node->left = rotateLeft(node->left);
  return rotateRight(node);
}

// Rotacion doble Derecha-Izquierda (Caso RL)
template <typename T>
AVLNode<T>* AVLTree<T>::rotateRightLeft(AVLNode<T>* node) {
  node->right = rotateRight(node->right);
  return rotateLeft(node);
}

template <typename T>
void AVLTree<T>::insert(const T& value) {
  bool inserted = false;
  root = insertHelper(root, value, inserted);
  if (inserted) {
    nodeCount++;
  }
}

template <typename T>
AVLNode<T>* AVLTree<T>::insertHelper(AVLNode<T>* node, const T& value, bool& inserted) {
  // 1. Insercion normal de ABB
  if (node == nullptr) {
    inserted = true;
    return new AVLNode<T>(value);
  }

  if (value < node->data) {
    node->left = insertHelper(node->left, value, inserted);
  } else if (value > node->data) {
    node->right = insertHelper(node->right, value, inserted);
  } else {
    // No se permiten duplicados en este arbol
    inserted = false;
    return node;
  }

  // 2. Actualizar altura del nodo ancestro
  updateHeight(node);

  // 3. Revisar factor de balance para ver si se desbalanceo
  int balance = getBalanceFactor(node);

  // Caso LL
  if (balance > 1 && value < node->left->data) {
    return rotateRight(node);
  }

  // Caso RR
  if (balance < -1 && value > node->right->data) {
    return rotateLeft(node);
  }

  // Caso LR
  if (balance > 1 && value > node->left->data) {
    return rotateLeftRight(node);
  }

  // Caso RL
  if (balance < -1 && value < node->right->data) {
    return rotateRightLeft(node);
  }

  return node;
}

template <typename T>
AVLNode<T>* AVLTree<T>::minValueNode(AVLNode<T>* node) const {
  AVLNode<T>* current = node;
  while (current != nullptr && current->left != nullptr) {
    current = current->left;
  }
  return current;
}

template <typename T>
AVLNode<T>* AVLTree<T>::maxValueNode(AVLNode<T>* node) const {
  AVLNode<T>* current = node;
  while (current != nullptr && current->right != nullptr) {
    current = current->right;
  }
  return current;
}

template <typename T>
void AVLTree<T>::remove(const T& value) {
  bool removed = false;
  root = removeHelper(root, value, removed);
  if (removed) {
    nodeCount--;
  }
}

template <typename T>
AVLNode<T>* AVLTree<T>::removeHelper(AVLNode<T>* node, const T& value, bool& removed) {
  if (node == nullptr) {
    return node;
  }

  if (value < node->data) {
    node->left = removeHelper(node->left, value, removed);
  } else if (value > node->data) {
    node->right = removeHelper(node->right, value, removed);
  } else {
    // Encontramos el nodo a borrar
    removed = true;

    // Nodo con 0 o 1 hijo
    if (node->left == nullptr || node->right == nullptr) {
      AVLNode<T>* temp = (node->left != nullptr) ? node->left : node->right;

      if (temp == nullptr) {
        // Sin hijos
        temp = node;
        node = nullptr;
      } else {
        // Con un hijo: copiamos contenido y borramos el hijo
        *node = *temp;
      }
      delete temp;
    } else {
      // Nodo con 2 hijos: buscamos el sucesor in-order (minimo del subarbol derecho)
      AVLNode<T>* temp = minValueNode(node->right);
      node->data = temp->data;
      bool dummyRemoved = false;
      node->right = removeHelper(node->right, temp->data, dummyRemoved);
    }
  }

  // Si el arbol tenia solo un nodo y se borro
  if (node == nullptr) {
    return node;
  }

  // Actualizar altura y rebalancear
  updateHeight(node);
  int balance = getBalanceFactor(node);

  // Caso LL
  if (balance > 1 && getBalanceFactor(node->left) >= 0) {
    return rotateRight(node);
  }

  // Caso LR
  if (balance > 1 && getBalanceFactor(node->left) < 0) {
    return rotateLeftRight(node);
  }

  // Caso RR
  if (balance < -1 && getBalanceFactor(node->right) <= 0) {
    return rotateLeft(node);
  }

  // Caso RL
  if (balance < -1 && getBalanceFactor(node->right) > 0) {
    return rotateRightLeft(node);
  }

  return node;
}

template <typename T>
bool AVLTree<T>::search(const T& value) const {
  return searchHelper(root, value);
}

template <typename T>
bool AVLTree<T>::searchHelper(AVLNode<T>* node, const T& value) const {
  if (node == nullptr) {
    return false;
  }
  if (value == node->data) {
    return true;
  }
  if (value < node->data) {
    return searchHelper(node->left, value);
  }
  return searchHelper(node->right, value);
}

template <typename T>
const T& AVLTree<T>::findMin() const {
  if (root == nullptr) {
    throw std::runtime_error("Error: el arbol esta vacio, no hay minimo.");
  }
  return minValueNode(root)->data;
}

template <typename T>
const T& AVLTree<T>::findMax() const {
  if (root == nullptr) {
    throw std::runtime_error("Error: el arbol esta vacio, no hay maximo.");
  }
  return maxValueNode(root)->data;
}

template <typename T>
int AVLTree<T>::getHeight() const {
  return nodeHeight(root);
}

template <typename T>
int AVLTree<T>::getSize() const {
  return nodeCount;
}

template <typename T>
void AVLTree<T>::clear() {
  clearHelper(root);
  root = nullptr;
  nodeCount = 0;
}

template <typename T>
void AVLTree<T>::clearHelper(AVLNode<T>* node) {
  if (node != nullptr) {
    clearHelper(node->left);
    clearHelper(node->right);
    delete node;
  }
}

template <typename T>
void AVLTree<T>::inOrder() const {
  inOrderHelper(root);
  std::cout << std::endl;
}

template <typename T>
void AVLTree<T>::inOrderHelper(AVLNode<T>* node) const {
  if (node != nullptr) {
    inOrderHelper(node->left);
    std::cout << node->data << " ";
    inOrderHelper(node->right);
  }
}

template <typename T>
void AVLTree<T>::preOrder() const {
  preOrderHelper(root);
  std::cout << std::endl;
}

template <typename T>
void AVLTree<T>::preOrderHelper(AVLNode<T>* node) const {
  if (node != nullptr) {
    std::cout << node->data << " ";
    preOrderHelper(node->left);
    preOrderHelper(node->right);
  }
}

template <typename T>
void AVLTree<T>::postOrder() const {
  postOrderHelper(root);
  std::cout << std::endl;
}

template <typename T>
void AVLTree<T>::postOrderHelper(AVLNode<T>* node) const {
  if (node != nullptr) {
    postOrderHelper(node->left);
    postOrderHelper(node->right);
    std::cout << node->data << " ";
  }
}

template <typename T>
void AVLTree<T>::levelOrder() const {
  if (root == nullptr) {
    std::cout << "(Arbol vacio)" << std::endl;
    return;
  }

  std::queue<AVLNode<T>*> q;
  q.push(root);

  while (!q.empty()) {
    AVLNode<T>* current = q.front();
    q.pop();

    std::cout << current->data << " ";

    if (current->left != nullptr) {
      q.push(current->left);
    }
    if (current->right != nullptr) {
      q.push(current->right);
    }
  }
  std::cout << std::endl;
}

#endif  // AVLTREE_CPP
